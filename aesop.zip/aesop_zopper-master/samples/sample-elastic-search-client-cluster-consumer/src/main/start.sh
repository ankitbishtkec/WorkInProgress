java -cp "lib/*" org.trpr.platform.runtime.impl.bootstrap.BootstrapLauncher resources/external/bootstrap.xml
