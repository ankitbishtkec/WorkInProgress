# AESOP,Zookeeper Multicluster and Kafka multibroker setup
`
Usage:- ansible-playbook -i hosts playbook.yml -u user_name
`

Update the variables 'zk_cluster_info' and 'kafka_cluster_info' in group_vars/all.yml according to the environment being used.

