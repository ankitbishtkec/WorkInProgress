open-replicator
===============

Open Replicator is a high performance MySQL binlog parser written in Java. It unfolds the possibilities that you can parse, filter and broadcast the binlog events in a real time manner.
Open Replicator has been forked from the original source. At Flipkart changes have been made to support MySql v5.6 and checksum.
Changing the Group Id so that it can be published to a public repository.
